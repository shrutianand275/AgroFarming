import React from "react";
import "./Footer.css";
import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
} from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">

        <div className="row align-items-center">

          <div className="col-lg-6 col-md-6 mb-3">
            <h3 className="footer-logo">🌱 AgroFarming</h3>
            <p>
              AI-powered Smart Farming for better crop decisions and higher productivity.
            </p>
          </div>

          <div className="col-lg-6 col-md-6 text-lg-end text-md-end">

            <div className="social-icons">
              <a href="#"><FaFacebookF /></a>
              <a href="#"><FaInstagram /></a>
              <a href="#"><FaLinkedinIn /></a>
            </div>

          </div>

        </div>

        <hr />

        <div className="footer-bottom">
          @ 2026 AgroFarming • Smart Farming System
        </div>

      </div>
    </footer>
  );
};

export default Footer;