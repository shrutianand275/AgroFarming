import "./Navbar.css";

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
      <div className="container">

        <a className="navbar-brand fw-bold text-success" href="/">
        🌿 AgroFarming
        </a>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarContent">

          <ul className="navbar-nav ms-auto">

            <li className="nav-item">
              <a className="nav-link active" href="#">
                Home
              </a>
            </li>

            <li className="nav-item">
              <a className="nav-link" href="#">
                About
              </a>
            </li>

            <li className="nav-item dropdown">

              <a
                className="nav-link dropdown-toggle"
                href="#"
                data-bs-toggle="dropdown"
              >
                AI Services
              </a>

              <ul className="dropdown-menu">

                <li><a className="dropdown-item" href="#">Crop Recommendation</a></li>

                <li><a className="dropdown-item" href="#">Yield Prediction</a></li>

                <li><a className="dropdown-item" href="#">Disease Prediction</a></li>

                <li><a className="dropdown-item" href="#">Fertilizer Recommendation</a></li>

                <li><a className="dropdown-item" href="#">Weather Forecast</a></li>

              </ul>

            </li>

            <li className="nav-item">
              <a className="nav-link" href="#">
                Government Schemes
              </a>
            </li>

            <li className="nav-item">
              <a className="nav-link" href="#">
                AI Chatbot
              </a>
            </li>

            <li className="nav-item ms-3">
              <button className="btn btn-success">
                Login
              </button>
            </li>

          </ul>

        </div>

      </div>
    </nav>
  );
}

export default Navbar;